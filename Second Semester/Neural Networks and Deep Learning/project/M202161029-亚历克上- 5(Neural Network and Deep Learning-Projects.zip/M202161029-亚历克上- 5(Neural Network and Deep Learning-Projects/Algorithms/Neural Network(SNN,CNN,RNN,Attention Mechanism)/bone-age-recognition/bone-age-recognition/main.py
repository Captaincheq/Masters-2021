from train import train
from test import test

if __name__ == "__main__":
    print('start!')
    train()
